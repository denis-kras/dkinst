"""Den K Simple Installer"""

__author__ = "Den Kras"
__version__ = '0.3.0'