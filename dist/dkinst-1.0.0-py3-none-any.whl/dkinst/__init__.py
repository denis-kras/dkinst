"""Den K Simple Installer"""

__author__ = "Den Kras"
__version__ = '1.0.0'